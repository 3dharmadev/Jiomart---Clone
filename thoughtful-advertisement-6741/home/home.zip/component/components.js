let navbar=()=>{
    return `
    <div id="kcnavbarhead">
    <!-- <img scr=""> -->
    <img src="https://www.jiomart.com/assets/version1662994539/smartweb/images/jiomart_logo_beta.svg">
    <input type="text" id="kcsearch" placeholder=  "    Search essentials, groceries, and more...">
    <div id="kcnavbarusername">
      <img src="https://www.jiomart.com/assets/version1664452279/smartweb/images/icons/profile.svg">
      <p id="sig">Sign in / Sign up</p>
    </div>

    <div id="kccart">
      <img src="https://www.jiomart.com/assets/version1664452279/smartweb/images/icons/cart.svg">
      <h3>Cart</h3>
    </div>
    
  </div>
  <!-- Navbar Menu -->
    <div id="menu">
        <div id="menu1">
          <ul id="main_menu">
            <li class="main_list"><b>Groceries</b>
            <ul>
            <ol>
            <li>Fruits & Vegetables</li>
            <li>Dairy & Bakery</li>
            <li>Staples</li>
            <li>Snacks & Branded Foods</li>
            <li>Beverages</li>
            <li>Personal Care</li>
            </ol>
  
            <ol>
            <li>Home Care</li>
            <li>Home & Kitchen</li></a>
            <li>Mom & Baby Care</li>
            <li>Books</li>
            <li> Pets</li>
            </ol>
            </ul>
            </li>
            
            <li class="main1_list"><b>Premium Fruits</b>
              <ul>
              <ol>
              <li>Apples & Pears</li>
              <li>Avocado, Peach, Plum</li>
              <li>Banana, Melons & Coconut</li>
              <li>Cherries, Berries & Exotic</li>
              <li>Fruits</li>
              <li>Citrus,Mango & Grapes</li>
              </ol>
              
              <ol>
             <li>Date</li>
             <li>Gift,Assorted & XL Packs</li>
             <li>Pomegranate, Papaya &</li>
             <li>Pineapple</li>
             <li>Seasonal & Minor Fruits</li>
              </ol>
              </ul>
              </li>
              
              <li class="main2_list"><b>Home & Kitchen</b>
                <ul>
                <ol>
                  <li>Kitchenware</li>
                  <li>Dining</li>
                  <li>Furnishing</li>
                  <li>Home Decor</li>
                  <li>Furniture</li>
                  <li>Home Appliances</li>
                  <li>Toys, Games & Fitness</li>
                  <li>Electrical</li>
                  <li>Bathroom & Laundry</li>
                  <li>Accessories</li>
                  <li>Disposables</li>
                  <li>Stationery</li>
                  </ol>

                  <ol>
                    <li>Bags & Travel Luggage</li>
                    <li>Mops, Brushes & Scrubs</li>
                    <li>Auto Care</li>
                    <li>Carpentry & work accessories</li>
                    <li>Pooja Needs</li>
                    <li>Bathroom & Laundry</li>
                    <li>Industrial & Scientific Supplies</li>
                    <li>Home Safety & Automation</li>
                    <li>Kitchen & Bath Fixtues</li>
                    <li>Power & Hand Tools</li>
                    </ol>
                    </ul>
                    </li>
                
                <li class="main3_list"><b>Fashion</b>
                <ul>
                <ol>
                <li>Men</li>
                <li>Women</li>
                <li>Boys</li>
                <li>Girls</li>
                <li>Infants</li>
                </ol>
                </ul>
                </li>
                
                <li class="main4_list"><b>Electronics</b>
                <ul>
                <ol>
                <li>Mobiles & Tablets</li>
                <li>Tv & Speaker</li>
                <li>Home Appliances</li>
                <li>Computers</li>
                <li>Cameras</li>
                <li>Kitchen Appliances</li>
                <li>Personal Care & Grooming</li>
                <li>Smart Devices</li>
                <li>Gaming</li>
                <li>Accessories</li>
                <li>Phone</li>
                <li>Office Products</li>
                <li>Health Care Devices</li>
                </ol>
                </ul>
                </li>
                
                <li class="main5_list"><b>Beauty</b>
                  <ul>                
                  <ol>
                  <li>Make-Up</li>
                  <li>Hair</li>
                  <li>Skin Care</li>
                  <li>Fragrances</li>
                  <li>Personal Care</li>
                  <li>Mon & Baby</li>
                  <li> Men's Grooming</li>
                  <li>Tools & Appliances</li>
                  <li>Covid Essentials</li>
                  <li>Wellness</li>
                  <li>Fitness</li>
                  <li>Ayush</li>
                  </ol>
                  </ul></li>
                  
                
                  <li class="main6_list"><b>Jewellery</b>
                    <ul>
                    <ol>
                    <li>Fine Jewllery</li>
                    <li>Jewellery</li>
                    </ol>
                    </ul>
                   </li>     
                  </div>
          
      </div>`
}

export {navbar};